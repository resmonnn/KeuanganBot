# KeuanganBot

Bot WhatsApp untuk mencatat pengeluaran yang tersimpan di Google Spreadsheet.

## Cara pakai

1. Upload semua file ke repository GitHub.
2. Deploy ke Render dengan environment variables:
   - TWILIO_WHATSAPP_NUMBER
   - SPREADSHEET_ID
   - GOOGLE_SHEETS_CREDENTIALS (isi JSON service account Google dalam bentuk string)
3. Set webhook di Twilio ke URL Render /webhook.
4. Kirim pesan WhatsApp ke nomor Twilio dengan format:
   pengeluaran 500 makan
